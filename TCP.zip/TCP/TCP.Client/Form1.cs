﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace TCP.Client
{
    public partial class Form1 : Form
    {
        //TcpClient m_tcpClient;
        public Form1()
        {
            InitializeComponent();
            //m_tcpClient = new TcpClient();
            

        }



        private void buttonSendMessage_Click(object sender, EventArgs e)
        {
            TcpClient tcpClient = new TcpClient();
            tcpClient.Connect(IPAddress.Parse(textBoxHostName.Text), Int32.Parse(textBoxPort.Text));

            NetworkStream ns = tcpClient.GetStream();


            if (ns.CanWrite)
            {
                Byte[] sendBytes = Encoding.UTF8.GetBytes(textBoxMessage.Text);
                ns.Write(sendBytes, 0, sendBytes.Length);
            }
            else
            {
                MessageBox.Show("不能写入数据流", "终止", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //Console.WriteLine("You cannot write data to this stream.");
                //m_tcpClient.Close();

                // Closing the tcpClient instance does not close the network stream.
                ns.Close();
                return;
            }


            ns.Close();
            //tcpClient.Close();

        }
    }
}
