﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace TCP.Server
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //Thread thread = new Thread(new ThreadStart(Listen));

            
            Thread thread = new Thread(new ThreadStart(SocketListen));

            thread.Start();

            IPAddress ipAddress = IPAddress.Any; //IPAddress.Parse("172.16.102.11");


            this.Text = ipAddress.ToString() + "正在监听...";

        }

        protected delegate void UpdateDisplayDelegate(string text);


        public void Listen()
        {
            IPAddress ipAddress = IPAddress.Any; //IPAddress.Parse("172.16.102.11");




            TcpListener tcpListener = new TcpListener(ipAddress, 9999);
            tcpListener.Start();

            TcpClient tcpClient = tcpListener.AcceptTcpClient();


            NetworkStream ns = tcpClient.GetStream();

            StreamReader sr = new StreamReader(ns);

            string result = sr.ReadToEnd();

            Invoke(new UpdateDisplayDelegate(UpdateDisplay), new object[] { result });

            tcpClient.Close();
            tcpListener.Stop();
        }

        public void SocketListen()
        {
            Socket listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            listener.Bind(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9998));

            listener.Listen(0);

            while(true)
            { 
                Socket socket = listener.Accept();
                Stream netStream = new NetworkStream(socket);
                StreamReader reader = new StreamReader(netStream);

                string result = reader.ReadToEnd();
                Invoke(new UpdateDisplayDelegate(UpdateDisplay), new object[] { result });

                socket.Close();
                
            }

            listener.Close();


        }

        public void UpdateDisplay(string text)
        {
            richTextBox1.Text = text;
        }
    }
}
